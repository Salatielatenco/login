<div id="graficaCircular"></div>

<script type="text/javascript">
	
	var data = [{
		values: [19, 26, 55,100],
		labels: ['Residential', 'Non-Residential', 'Utility','prueba'],
		type: 'pie'
	}];

	var layout = {
		height: 400,
		width: 500
	};

	Plotly.newPlot('graficaCircular', data, layout);


</script>