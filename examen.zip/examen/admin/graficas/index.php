<!DOCTYPE html>
<html>
<head>
	<title>Graficos con plotly</title>
	<link rel="stylesheet" type="text/css" href="librerias/bootstrap/css/bootstrap.css">
	<script src="librerias/jquery-3.3.1.min.js"></script>
	<script src="librerias/plotly-latest.min.js"></script>
	<link rel="icon" type="image/ico" href="../../img/favicon.ico" />
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="panel panel-primary">
					<div class="panel panel-heading">
						Graficas con plotly js (facultad autodidacta)
					</div>
					<div class="panel panel-body">
						<div class="row">
							<div class="col-sm-6">
								<div id="cargaLineal"></div>
							</div>
							<div class="col-sm-6">
								<div id="cargaBarras"></div>
							</div>
							<div class="col-sm-6">
								<div id="cargaCircular"></div>
							</div>
							<div class="col-sm-6">
								<div id="cargaCircular2"></div>
							</div>
							<div class="col-sm-6">
								<div id="cargaCircular3"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

<script type="text/javascript">
	$(document).ready(function(){
		$('#cargaLineal').load('lineal.php');
		$('#cargaBarras').load('barras.php');
		$('#cargaCircular').load('circular.php');
		$('#cargaCircular2').load('circular2.php');
		$('#cargaCircular3').load('circular3.php');
	});
</script>
<?php
    require_once "php/conexion.php";
    $conexion=conexion();
    $sql="SELECT resultado from datos";
    $result=mysqli_query($conexion,$sql);
    $total=0;
    while ($row=mysqli_fetch_array($result)) {
    	$total=$total+$row['resultado'];
    }
    echo $total;
?>