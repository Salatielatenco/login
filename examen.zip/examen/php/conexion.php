

<?php 
	function conexion()
	{
		return $conexion=mysqli_connect("localhost:3306","tecmilpa_tachi","N0olv1d4r._","tecmilpa_prueba");
		//return$conexion = mysqli_connect("localhost", "root", "", "prueba");
	}

 ?>